# Social-Blade-Dashboard-C-WPF

Youtube Tutorial to design Material Design Social Blade Dashboard using material design XAML toolkit
Check out more videos on my youtube channel: https://www.youtube.com/c/CCodeAcademy

Tutorial Link:https://youtu.be/qSP8v8Gi3XU

Material Design XAML Toolkit: http://materialdesigninxaml.net/
